<?php
include 'core.php';

$_TITRE_PAGE = 'Accueil projet RS ESEO';

if(isset($_POST['connexion_submit']) && $_POST['connexion_submit'] == 1){ //on détecte que l'action
    //vient du bouton de la connexion
    if ($_POST['password'] == 'network') {
        $_SESSION['compte'] = true;
    }

}

$sql = "SELECT idEtu
        FROM Etudiant
        WHERE email = '".trim(isset($_POST['mail'])) . "'
        AND motDePasse = '".trim(isset($_POST['password'])) . "'";

$result = $mysqli->query($sql);
if (!$result) {
    exit($mysqli->error);
}
$nb = $result->num_rows;
if ($nb) {
    //récupération de l'id de l'étudiant
    $row = $result->fetch_assoc();
    $_SESSION['compte'] = $row['idEtu'];
}

echo $_POST[$row['mail']].'</br>';
echo $_POST[$row['motDePasse']];


?>

<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="utf-8">
    <title>
        <?php echo $_TITRE_PAGE ?>
    </title>
</head>

<body>
    <div>
        <h2>Bienvenue sur RS ESEO</h2>
        <?php
        if (!$_SESSION['compte']) {
            ?>
            <div>
                <form method="post">
                    <p>Connexion</p>
                    <p>
                        <label for="idmail">Email</label>
                        <input id="idmail" name="mail" type="text">
                    </p>
                    <p>
                        <label for="defaultLoginFormPassword">Mot de passe</label>
                        <input name="password" type="password" id="defaultLoginFormPassword">
                    </p>
                    <button name="connexion_submit" value="1" type="submit">Connexion</button>

                </form>
            </div>
            <?php
        } else {
            ?>
            <div>
                <h2>Vous êtes connecté !</h2>
                <a href="http://192.168.56.80/pwnd?logout=1">Se déconnecter</a>
            </div>
            <?php
        }
        ?>
    </div>
</body>

</html>